Neo4j Coordinator Data
=======================================

This directory is used by a running Neo4j Cluster Coordinator instance.
The `myid` file must contain a unique ID for this Coordinator within
the cluster of coordinators.


