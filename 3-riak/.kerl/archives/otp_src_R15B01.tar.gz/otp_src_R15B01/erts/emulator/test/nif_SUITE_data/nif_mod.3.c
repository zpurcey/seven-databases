#define NIF_LIB_VER 3
#include "nif_mod.c"
