#define NIF_LIB_VER 2
#include "nif_mod.c"
